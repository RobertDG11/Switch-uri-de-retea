/*
	Autor: Stancu Florin
	Grupa: 334CB
*/

#define _CRT_SECURE_NO_DEPRECATE

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "HashTable.h"

/*
	Functie pentru hashcode.
*/

unsigned int hash(const char *str, unsigned int hash_length) {

	unsigned int hash = 5381;
	int c;

	while ((c = *str++) != 0)
		hash = ((hash << 5) + hash) + c; // hash * 33 + c

	return (hash % hash_length);

}

/*
	Functie care-mi creeaza un nou dictionar.
*/

HashTable create_hashtable(int size) {

	int i;
	HashTable hashtable;

	hashtable.bucketlist = (LBucket) malloc(sizeof(Bucket) * size);
	if (hashtable.bucketlist == NULL) {
		printf("Nu s-a putut aloca memorie pentru bucketlist.");
		exit(0);
	}

	for (i = 0; i < size; i++)
		hashtable.bucketlist[i] = NULL;

	hashtable.size = size;

	return hashtable;

}

/*
	Functie care-mi adauga un nou cuvant in dictionar.
*/

void add_bucket(HashTable hashtable, char* word) {

	int index;
	Bucket bucket;

	index = hash(word, hashtable.size);
	bucket = hashtable.bucketlist[index];

	// daca nu s-a mai introdus nimic in acesta lista de bucket-uri
	if (hashtable.bucketlist[index] == NULL) {

		hashtable.bucketlist[index] = (Bucket) malloc(sizeof(struct cell));
		if (hashtable.bucketlist[index] == NULL) {
			printf("Nu s-a putut aloca memorie pentru bucket.");
			exit(0);
		}

		hashtable.bucketlist[index]->next = NULL;
		hashtable.bucketlist[index]->val = (char*)malloc(strlen(word) + 1);
		if (hashtable.bucketlist[index]->val == NULL) {
			printf("Nu s-a putut aloca memorie pentru word.\n");
			exit(0);
		}
		memcpy(hashtable.bucketlist[index]->val, word, strlen(word) + 1);

	// s-a mai adaugat ceva in lista asta de bucket-uri
	// si caut sa vad daca mai exista cuvantul in lista
	} else {

		bucket = hashtable.bucketlist[index];
		while (1) {
		
			// verific bucket-ul curent pentru duplicate
			if (strcmp(word, bucket->val) == 0)
				break;

			// daca n-am gasit duplicat si am ajuns la final
			// adaug un nou bucket
			if (bucket->next == NULL) {

				// adaug noul cuvant
				bucket->next = (Bucket) malloc(sizeof(struct cell));
				if (bucket->next == NULL) {
					printf("Nu s-a putut aloca memorie pentru bucket.");
					exit(0);
				}

				bucket->next->next = NULL;
				bucket->next->val = (char*)malloc(strlen(word) + 1);
				if (bucket->next->val == NULL) {
					printf("Nu s-a putut aloca memorie pentru word.\n");
					exit(0);
				}
				memcpy(bucket->next->val, word, strlen(word) + 1);
				break;

			}

			// altfel, merg mai departe
			bucket = bucket->next;

		}

	}

}

/*
	Functie care-mi sterge un cuvant din dictionar.
*/

void remove_bucket(HashTable hashtable, char* word) {

	int index;
	Bucket bucket, next_bucket;

	index = hash(word, hashtable.size);

	// daca exista lista cu bucket-uri respectiva
	if (hashtable.bucketlist[index] != NULL) {
	
		// vad daca cuvantul cautat se afla pe prima pozitie
		bucket = hashtable.bucketlist[index];
		if (strcmp(bucket->val, word) == 0) {

			hashtable.bucketlist[index] = bucket->next;
			free(bucket);

		// daca nu, caut mai departe
		} else {
		
			next_bucket = bucket->next;
			while (next_bucket != NULL) {
			
				// daca am gasit cuvantul cautat
				if (strcmp(next_bucket->val, word) == 0) {
					bucket->next = next_bucket->next;
					free(next_bucket);
					break;
				}

				next_bucket = next_bucket->next;
				bucket = bucket->next;

			}

		}

	}

}

/*
	Functie care-mi verifica daca un cuvant exista sau nu in dictionar.
*/

void find_bucket(HashTable hashtable, char* word, char* file_name) {

	int index;
	Bucket bucket;

	index = hash(word, hashtable.size);
	bucket = hashtable.bucketlist[index];

	while (bucket != NULL) {

		// daca l-am gasit
		if (strcmp(word, bucket->val) == 0) {
			write_data("True", file_name);
			return;
		}

		bucket = bucket->next;

	}

	write_data("False", file_name);
	return;

}

/*
	Functie care-mi afiseaza o lista de bucket-uri.
*/

void print_bucket(HashTable hashtable, int index, char* file_name) {

	Bucket bucket;
	FILE *file;
	int am_afisat_ceva = 0;

	bucket = hashtable.bucketlist[index];

	// daca e NULL fac afisarea la consola
	if (file_name == NULL) {
	
		while (bucket != NULL) {
			printf("%s ", bucket->val);
			bucket = bucket->next;
			am_afisat_ceva = 1;
		}

		// trec pe linia urmatoare doar daca am afisat ceva
		// evit astfel liniile goale
		if (am_afisat_ceva)
			printf("\n");

	// aici se scrie in fisier
	} else {
	
		file = fopen(file_name, "a");
		if (file == NULL) {
			printf("Nu s-a putut scrie in fisierul %s.", file_name);
			exit(0);
		}

		while (bucket != NULL) {
			fprintf(file, "%s ", bucket->val);
			bucket = bucket->next;
			am_afisat_ceva = 1;
		}

		if (am_afisat_ceva)
			fprintf(file, "\n");
		
		fclose(file);

	}

}

/*
	Functie care-mi afiseaza intregul dictionar.
	Ma folosesc de functia care afiseaza o lista de bucket-uri.
*/

void print_hashtable(HashTable hashtable, char* file_name) {

	int i;
	for (i = 0; i < hashtable.size; i++)
		print_bucket(hashtable, i, file_name);

}

/*
	Functie care-mi redimentsioneaza dictionarul.
	Daca "indice_scalare" este egal cu 2, se dubleaza dictionarul.
	Daca "indice_scalare" este egal cu 0.5 se injumatateste dictionarul.
*/

HashTable resize_hashtable(HashTable old_hashtable, float indice_scalare) {

	HashTable new_hashtable;
	Bucket bucket, prev_bucket; // variabile folosite pentru a dezaloca memorie
	int new_size = (int)floor(old_hashtable.size * indice_scalare);
	int i;

	new_hashtable.size = new_size;
	new_hashtable.bucketlist = (LBucket) malloc(sizeof(struct cell) * new_size);
	if (new_hashtable.bucketlist == NULL) {
		printf("Nu s-a putut aloca noul dictionar.");
		exit(0);
	}

	for (i = 0; i < new_size; i++)
		new_hashtable.bucketlist[i] = NULL;

	// incepe copierea elementelor in nou dictionar
	for (i = 0; i < old_hashtable.size; i++) {
		bucket = old_hashtable.bucketlist[i];
		while (bucket != NULL) {
			add_bucket(new_hashtable, bucket->val);
			prev_bucket = bucket;
			bucket = bucket->next;
			free(prev_bucket); // eliberez memoria din vechiul dictionar
		}
	}

	free(old_hashtable.bucketlist);

	return new_hashtable;

}

/*
	Functie care-mi goleste dictionarul.
*/

void clear_hashtable(HashTable hashtable) {

	int i;
	Bucket bucket, prev_bucket;

	for (i = 0; i < hashtable.size; i++) {
	
		bucket = hashtable.bucketlist[i];
		while (bucket != NULL) {
		
			prev_bucket = bucket;
			bucket = bucket->next;
			free(prev_bucket);

		}

		hashtable.bucketlist[i] = NULL;

	}

}

/*
	Functie care-mi dezaloca memoria pentru un dictionar.
	Este apelata la finaul programului pentru a nu avea leak-uri de memorie.
*/

void delete_hashtable(HashTable hashtable) {

	Bucket bucket, pre_bucket;
	int i;

	for (i = 0; i < hashtable.size; i++) {
	
		bucket = hashtable.bucketlist[i];
		while (bucket != NULL) {
		
			pre_bucket = bucket;
			bucket = bucket->next;
			free(pre_bucket);

		}

	}

	free(hashtable.bucketlist);

}

/*
	Functie care-mi afiseaza un mesaj.
	Daca "file_name" este NULL afiseaza pe ecran, altfel afiseaza in fisier.
*/

void write_data(char* msg, char* file_name) {

	FILE* file;
	if (file_name == NULL) {
	
		printf("%s\n", msg);
	
	} else {
	
		file = fopen(file_name, "a");
		if (file == NULL) {
			printf("Nu s-a putut deschide fisierul %s.\n", file_name);
			exit(0);
		}

		fprintf(file, "%s\n", msg);
		fclose(file);

	}

}