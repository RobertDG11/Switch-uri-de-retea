/*
	Autor: Stancu Florin
	Grupa: 334CB
*/

typedef struct cell {
	char *val;
	struct cell *next;
} *Bucket, **LBucket;

typedef struct {
	LBucket bucketlist;
	int size;
} HashTable;

#define ADD 1
#define REMOVE 2
#define FIND 3
#define BUCKET 4
#define PRINT 5
#define RESIZE 6
#define CLEAR 7
#define NONE 0

HashTable create_hashtable(int size);
void add_bucket(HashTable hashtable, char* word);
void remove_bucket(HashTable hashtable, char* word);
void find_bucket(HashTable hashtable, char* word, char* file_name);
void print_bucket(HashTable hashtable, int index, char* file_name);
void print_hashtable(HashTable hashtable, char* file_name);
void clear_hashtable(HashTable hashtable);
HashTable resize_hashtable(HashTable old_hashtable, float indice_scalare);
void delete_hashtable(HashTable hashtable);
void write_data(char* msg, char* file_name);
unsigned int hash(const char *str, unsigned int hash_length);