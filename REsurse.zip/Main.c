/*
	Autor: Stancu Florin
	Grupa: 334CB
*/

#define _CRT_SECURE_NO_DEPRECATE
	
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "HashTable.h"

/*
	Functie care-mi proceseaza o comanda.
	AKA o linie din fisier / STDIN
*/

void proceseaza_operatie(HashTable *hashtable, char* line) {

	char *ch = NULL, *word = NULL;
	int operatie = NONE;
	int i = 0;
	float indice_scalare = 1;
	HashTable new_hashtable;

	//line[strlen(line) - 1] = '\0';
	ch = strtok(line, " \n");
	while(ch != NULL) {

		// salvez tipul operatiei
		if (operatie == NONE) {

			if (strcmp(ch, "add") == 0)
				operatie = ADD;
			else if (strcmp(ch, "remove") == 0)
				operatie = REMOVE;
			else if (strcmp(ch, "find") == 0)
				operatie = FIND;
			else if (strcmp(ch, "print_bucket") == 0)
				operatie = BUCKET;
			else if (strcmp(ch, "print") == 0)
				operatie = PRINT;
			else if (strcmp(ch, "resize") == 0)
				operatie = RESIZE;
			else if (strcmp(ch, "clear") == 0)
				operatie = CLEAR;
		
		// si urmatorul cuvant de dupa operatie
		} else {
		
			word = ch;

		}

		// al 3-lea cuvant imi ramane in "ch"
		// sau ch e NULL in caz ca nu exista
		ch = strtok(NULL, " \n");
		i++;

		if (i == 2)
			break;

	}

	if (operatie == ADD)
		add_bucket(*hashtable, word);
	else if (operatie == REMOVE)
		remove_bucket(*hashtable, word);
	else if (operatie == FIND)
		find_bucket(*hashtable, word, ch);
	else if (operatie == BUCKET) {
		i = atoi(word);
		print_bucket(*hashtable, i, ch);
	} else if (operatie == PRINT)
		print_hashtable(*hashtable, word);
	else if (operatie == CLEAR)
		clear_hashtable(*hashtable);
	else if (operatie == RESIZE) {
		
		if (strcmp(word, "double") == 0)
			indice_scalare = 2;
		else if (strcmp(word, "halve") == 0)
			indice_scalare = 0.5;

		new_hashtable = resize_hashtable(*hashtable, indice_scalare);
		*hashtable = new_hashtable;

	}

}

/*
	Functia main.
*/

int main(int argc, char **argv) {

	int size, nr_fisiere_intrare;
	char line[20000];
	FILE *file;
	int i;
	HashTable hashtable;

	size = atoi(argv[1]);
	hashtable = create_hashtable(size);

	nr_fisiere_intrare = argc - 2;

	// daca citirea se face de la STDIN
	if (nr_fisiere_intrare == 0) {

		while (fgets(line, sizeof line, stdin) != NULL ) {
		
			proceseaza_operatie(&hashtable, line);

		}

	} else {
	
		for (i = 0; i < nr_fisiere_intrare; i++) {
		
			file = fopen(argv[i + 2], "r");
			if (file == NULL) {
				printf("Nu s-a putut deschide fisierul %s.\n", argv[i + 2]);
				exit(0);
			}

			while (fgets(line, sizeof line, file) != NULL ) {
		
				proceseaza_operatie(&hashtable, line);

			}

			fclose(file);

		}

	}

	delete_hashtable(hashtable);

	return 0;

}